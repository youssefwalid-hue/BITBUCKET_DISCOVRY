# Guide utilisateur — Découverte des capacités Bitbucket Data Center

`bitbucket_discovery.py` v2.0 · 10 octobre 2026 · usage interne

> Ce guide s'adresse à la personne qui exécute l'outil de découverte des capacités Bitbucket Data Center (`bitbucket_discovery.py`, version 2.0) et à celles qui en lisent les résultats. Il couvre l'installation, la configuration, l'exécution, la lecture du rapport et le dépannage. Référence : spécification et cadrage v1.3, sections III.1, III.5, III.6, III.8 et V.1.

## Objet et garanties

L'outil est la première étape opérationnelle du pilote **Bitbucket Repository Intelligence**. En une exécution, il :

1. confirme la version de l'instance et la compare à la version déclarée (hypothèse H-01) ;
2. résout le périmètre pilote (décision D-01) et inventorie **tous** ses dépôts, ce qui fournit le dénominateur candidat (D-06) ;
3. sonde les 25 lignes du catalogue de collecte (API-01 à API-25) et attribue à chacune un état de collecte ;
4. mesure l'activité des dépôts (branches, tags, commits, pull requests, date du dernier commit) ;
5. produit un tableau de bord HTML autonome, un JSON complet, cinq exports CSV et un rapport Markdown, avec une synthèse et des propositions d'actions.

> **Trois garanties, par construction**
>
> - **Lecture seule** : le client HTTP ne sait construire que des requêtes GET ; le JSON atteste `calls_non_get = 0` et le code de retour passe à 1 si ce n'était pas le cas.
> - **Mode non nominatif** (D-05, pilote) : aucun contenu, aucun diff, aucune identité Git ni nom d'utilisateur ou de groupe n'est conservé ; seuls les noms de champs, les comptages, les statuts HTTP et les identifiants techniques (clé de projet, slug, SHA, numéro de PR) sont écrits.
> - **Aucun secret** dans les sorties ni dans les journaux ; les paramètres de requête ne sont jamais journalisés.

Les résultats sont classifiés **Interne** : ils décrivent la structure du patrimoine applicatif et les droits observés. Ils s'archivent avec le compte rendu du pilote.

## Installation et prérequis

| Prérequis | Détail |
|---|---|
| Python | 3.8 ou plus, **bibliothèque standard uniquement** : aucune installation de paquet (`pip`) n'est nécessaire, ce qui convient aux postes et serveurs sans accès aux dépôts publics. |
| Fichiers | `bitbucket_discovery.py` (l'outil) ; `mock_bitbucket_server.py` (simulateur de test, facultatif) ; ce guide. |
| Compte | le compte de service existant à droits complets (D-02) et son **jeton d'accès HTTP** (personal access token), à conserver en coffre-fort ; l'authentification basique reste possible. |
| Réseau | accès HTTPS à l'instance depuis le poste d'exécution, directement ou via le proxy d'entreprise ; le bundle de certificats de l'autorité interne si l'instance n'est pas signée par une autorité publique. |
| Poste | un dossier de travail avec droits d'écriture pour les sorties ; un navigateur récent pour le rapport HTML ; Excel ou LibreOffice pour les CSV. |

*Prérequis d'installation*

Installation : copier les fichiers dans un dossier dédié, par exemple `C:\Outils\discovery` ou `~/discovery`, puis vérifier l'interpréteur :

```bash
python --version        # Windows
python3 --version       # Linux / macOS
python bitbucket_discovery.py --help
```

## Configuration

### Le jeton et les secrets

Le jeton n'est jamais passé en ligne de commande (il apparaîtrait dans l'historique du shell et la liste des processus). Deux modes :

```bash
# Linux / macOS — variable d'environnement de la session courante
export BITBUCKET_TOKEN='<jeton du compte de service>'

# Windows PowerShell
$env:BITBUCKET_TOKEN = '<jeton du compte de service>'

# ou fichier protégé (une seule ligne), recommandé pour les exécutions planifiées
chmod 600 ~/.bitbucket_token
python bitbucket_discovery.py --token-file ~/.bitbucket_token ...
```

Authentification basique si l'instance l'impose : `--basic-user <compte>` avec le mot de passe dans `BITBUCKET_PASSWORD`. Le jeton est prioritaire s'il est présent.

### Réseau : proxy et certificats

- Le proxy est lu dans `HTTPS_PROXY` / `HTTP_PROXY` ; `NO_PROXY` est respecté. `--no-proxy` force l'accès direct.
- Une autorité de certification interne se déclare avec `--ca-bundle /chemin/ca-entreprise.pem` (format PEM, chaîne complète).
- `--insecure` désactive la vérification TLS : réservé à un test ponctuel, jamais pour la production du rapport pilote.
- Les redirections HTTP ne sont pas suivies : une redirection est signalée en ERROR, le plus souvent signe d'une URL de base incomplète.

### Les options

| Option | Rôle | Défaut |
|---|---|---|
| `--base-url` | URL de base de l'instance (obligatoire), ex. `https://bitbucket.exemple.local` ; inclure le chemin de contexte s'il existe (`/bitbucket`) | — |
| `--projects` | clés de projet du périmètre, séparées par des virgules (D-01) | tous les projets visibles |
| `--project-name-regex` | sinon : expression régulière sur le nom ou la clé des projets | — |
| `--profile` | `extended` = toutes les familles ; `base` = sans les familles à droits étendus (API-14 à API-19, API-21) | `extended` |
| `--details` | détails par dépôt (branches, tags, commits, PR, dernier commit) : `sample`, `all` ou `none` | `sample` |
| `--sample-repos` | nombre de dépôts détaillés en mode `sample` | 25 |
| `--sample-repo` | dépôt échantillon imposé pour les sondes : `CLE/slug` | premier dépôt avec un commit |
| `--declared-version`, `--declared-build` | version et build déclarés par l'exploitation (H-01) | 9.4.17 / 900417 |
| `--token-file` | fichier contenant le jeton (sinon variable `BITBUCKET_TOKEN`) | — |
| `--basic-user` | authentification basique : utilisateur, mot de passe dans `BITBUCKET_PASSWORD` | — |
| `--ca-bundle` | bundle PEM de l'autorité de certification interne | magasin système |
| `--no-proxy` | ignore `HTTPS_PROXY` / `HTTP_PROXY` | proxys de l'environnement |
| `--timeout` | délai maximal par appel (s) | 30 |
| `--delay` | pause entre deux appels (s) | 0,1 |
| `--max-retries` | reprises sur HTTP 429 et 5xx (backoff et `Retry-After`) | 3 |
| `--max-calls` | budget total d'appels GET ; au-delà, sondes restantes NOT_REQUESTED | 5 000 |
| `--max-pages` | pages maximales par liste (100 éléments par page) ; au-delà, comptage marqué tronqué | 50 |
| `--no-volumetry` | sondes seules : ni inventaire ni détails | — |
| `--dry-run` | liste les appels prévus sans en exécuter aucun | — |
| `--out` | dossier de sortie | `./discovery_out` |
| `--verbose` | journal détaillé (un message par appel, sans paramètre ni secret) | — |
| `--insecure` | désactive la vérification TLS — à proscrire hors test | — |

*Options de la ligne de commande*

## Exécution pas à pas

### Étape 0 — répétition à blanc

`--dry-run` liste les appels prévus sans en exécuter aucun. Il sert à vérifier la ligne de commande et le dossier de sortie ; il ne valide ni la connectivité ni le jeton.

```bash
python bitbucket_discovery.py --base-url https://bitbucket.exemple.local --projects BPCEIT,BPCECIB --dry-run --out ./discovery_out
```

### Étape 1 — test de connectivité

Une exécution limitée aux sondes (`--no-volumetry`) prend moins d'une minute et confirme l'accès, la version et les droits :

```bash
export BITBUCKET_TOKEN='<jeton>'
python bitbucket_discovery.py \
  --base-url https://bitbucket.exemple.local \
  --projects BPCEIT,BPCECIB \
  --ca-bundle /etc/ssl/certs/entreprise.pem \
  --no-volumetry --out ./discovery_out
```

Le journal affiche les six étapes. En cas de jeton refusé (401), d'instance injoignable ou de périmètre vide, l'outil **s'arrête** après l'étape 1 ou 2, produit tout de même les rapports avec une proposition unique et rend le code de retour 3.

### Étape 2 — exécution pilote

L'exécution complète inventorie tous les dépôts du périmètre et détaille un échantillon de 25 dépôts :

```bash
python bitbucket_discovery.py \
  --base-url https://bitbucket.exemple.local \
  --projects BPCEIT,BPCECIB \
  --declared-version 9.4.17 --declared-build 900417 \
  --ca-bundle /etc/ssl/certs/entreprise.pem \
  --out ./discovery_out
```

Pour mesurer l'activité de **tous** les dépôts (tranches ≤ 90 j, 91–365 j, > 365 j, sans commit), ajouter `--details all` : compter environ six appels par dépôt, soit une dizaine de minutes pour 1 000 dépôts avec le délai par défaut. Augmenter `--max-calls` en conséquence (par exemple 20 000).

### Étape 3 — relances ciblées

- `--sample-repo CLE/slug` : refaire les sondes sur un dépôt disposant de pull requests, de builds ou de rapports Code Insights lorsque des lignes sont NOT_REQUESTED « faute d'échantillon » ou en 404 sur un dépôt atypique.
- `--profile base` : vérifier ce que verrait un compte sans droits étendus (comparaison BASE / EXTENDED de la spécification III.6).
- `--max-pages 200` : lever une troncature signalée par « + » dans les comptages.
- `--project-name-regex 'BPCE ?(IT|CIB)'` : sélectionner par nom lorsque les clés exactes ne sont pas connues.

### Durée, volume et codes de retour

| Élément | Valeur indicative |
|---|---|
| Sondes du catalogue | une soixantaine d'appels, moins d'une minute |
| Inventaire | une page par tranche de 100 dépôts et par projet |
| Détails par dépôt | environ six appels par dépôt (`--details all`), cinq par défaut sur 25 dépôts |
| Code de retour 0 | exécution terminée |
| Code de retour 1 | un appel non GET a été détecté — ne doit jamais se produire ; alerter |
| Code de retour 2 | paramètres invalides ou secret absent |
| Code de retour 3 | arrêt anticipé : jeton refusé, instance injoignable ou périmètre vide (rapports produits) |

*Durées et codes de retour*

## Lecture des résultats

Chaque exécution écrit huit fichiers horodatés dans le dossier de sortie : `discovery_<date>.html`, `.json`, `.md` et cinq CSV. Le rapport HTML est **autonome** (aucune ressource externe, aucun script tiers) : il s'ouvre dans un navigateur, se partage par messagerie et s'imprime.

### Le tableau de bord HTML

![Tableau de bord du rapport HTML (exécution sur le simulateur)](exemples/dashboard.png)

*Tableau de bord du rapport HTML (exécution sur le simulateur)*

| Zone | Ce qu'elle montre | Comment la lire |
|---|---|---|
| Bandeau | horodatage, hôte, profil, périmètre, attestation « lecture seule, 0 écriture, mode non nominatif » | à citer dans le compte rendu du pilote |
| Tuiles KPI | version et statut H-01 ; lignes P0 disponibles ; lignes à vérifier ; projets et dépôts du périmètre ; archivés et forks ; dépôts détaillés ; appels GET | vert = acquis, ambre = à traiter, rouge = bloquant |
| Graphiques | lignes du catalogue par état ; dépôts par projet ; activité des dépôts détaillés | survoler une barre pour la valeur et la part du total |
| Instance, périmètre et échantillon | versions observée et déclarée ; mode de sélection ; projets visibles et retenus ; dépôt, commit et PR utilisés pour les sondes | un projet personnel visible n'est jamais retenu |
| Synthèse et propositions | verdict en quelques phrases puis propositions classées Acquis / Information / À traiter / Bloquant | c'est la liste des actions à décider avant le lot 1 |
| Catalogue API | les 25 lignes avec état, forme de réponse et détail dépliable des sondes (endpoint, HTTP, diagnostic) | ⚠ = une sonde en ERROR ou UNSUPPORTED à vérifier contre la documentation 9.4 |
| Inventaire des projets | dépôts, forks, archivés, publics par projet | somme = dénominateur candidat D-06 |
| Inventaire des dépôts | tous les dépôts avec filtre texte, filtre par projet et par activité ; 100 lignes par page | « + » = comptage tronqué ; colonnes de détail vides = dépôt non détaillé |
| Exécution | appels par statut HTTP, notes d'échantillonnage, budget, durée | un 429 isolé est normal ; des 5xx répétés sont à signaler à l'exploitation |
| Lecture des états | rappel des huit états et des suites à donner | — |

*Zones du rapport HTML*

### Le JSON — source de vérité

- `run` : horodatage, hôte, profil, périmètre, version déclarée, `read_only`, `non_nominative_mode`, `calls_total`, `calls_non_get`, budget, durée, `stopped_after_step` ;
- `instance` : version et build observés, `version_status` = CONFIRMED, CONFLICTING ou UNKNOWN ;
- `perimeter` : projets visibles, retenus, clés visibles et clés introuvables ;
- `samples` et `sample_notes` : échantillon des sondes (le nom du groupe n'est pas conservé) ;
- `capabilities` : une entrée par ligne API-01 à API-25 : `collection_status`, `compatibility_checked`, `to_verify`, et par sonde : endpoint, HTTP, état, forme (`paged` / `unit` / `list` / `raw`), pagination, enregistrements, `keys_observed`, durée, diagnostic ;
- `summary` : comptage par état, lignes P0 disponibles, lignes à vérifier ;
- `volumetry` : projets, dénominateur candidat, tranches d'activité ; `repositories` : l'inventaire complet avec les détails ;
- `calls` : journal des appels ; `propositions` : les propositions du rapport.

### Les exports CSV

Séparateur « ; », encodage UTF-8 avec BOM : les fichiers s'ouvrent directement dans Excel. Ils alimentent le registre de capacités (`L10_catalogue_api.yaml`), l'échantillon de contrôle et le dénominateur D-06.

| Fichier | Contenu | Colonnes |
|---|---|---|
| `projets_<date>.csv` | une ligne par projet du périmètre | clé, nom, type, public, nombre de dépôts, liste tronquée, état de collecte, forks, archivés, dépôts publics |
| `depots_<date>.csv` | une ligne par dépôt inventorié (inventaire complet) | projet, identifiant, slug, nom, état, archivé, public, forkable, fork et origine, SCM ; puis, pour les dépôts détaillés : branche par défaut, branches, tags, commits, PR (avec indicateur de troncature), dernier commit, jours écoulés, tranche d'activité |
| `capacites_<date>.csv` | une ligne par sonde du catalogue | ligne API, objet, priorité, état de la ligne, à vérifier, contrat vérifié, sonde, endpoint, variante, HTTP, état de la sonde, forme, enregistrements, diagnostic |
| `volumetrie_<date>.csv` | une ligne par dépôt détaillé | projet, dépôt, branche par défaut, branches, tags, commits, PR, dernier commit, jours, activité |
| `appels_<date>.csv` | journal des appels HTTP | horodatage, méthode (toujours GET), chemin sans paramètres, statut, durée, tentative |

*Exports CSV*

### Le rapport Markdown

`discovery_<date>.md` reprend la synthèse, le tableau du catalogue, la volumétrie, les propositions et les notes d'échantillonnage sous une forme lisible dans Bitbucket, Confluence ou un courriel : c'est la pièce à joindre au compte rendu.

## États de collecte et suites à donner

| État | Signification | Suite à donner |
|---|---|---|
| AVAILABLE | première page lue avec des enregistrements | contrat observé exploitable : reporter les champs (`keys_observed`) dans le catalogue |
| EMPTY | collecte autorisée, aucun résultat sur l'échantillon | normal pour forks, hooks, builds, rapports ; ne prouve rien au-delà de l'échantillon |
| PARTIAL | sondes d'une même ligne dans des états différents | lire le détail des sondes (JSON ou tableau HTML) |
| UNAUTHENTICATED | HTTP 401 | jeton absent, invalide ou expiré ; l'outil s'arrête après l'étape 1 |
| FORBIDDEN | HTTP 403 | revue des droits du compte de service (D-02) ; aucune élévation automatique |
| UNSUPPORTED | HTTP 405, 410 ou 501 | famille indisponible sur cette version : ligne à retirer du socle |
| ERROR | 404, 5xx, 429 persistant, redirection ou erreur technique | **un 404 ne vaut pas UNSUPPORTED** : vérifier la route (documentation 9.4) et l'échantillon |
| NOT_REQUESTED | profil, échantillon indisponible, budget épuisé ou arrêt anticipé | relancer avec `--profile extended`, un autre `--sample-repo` ou `--max-calls` plus élevé |

*Les huit états de collecte (spécification III.5)*

Les sondes marquées « variante » (`branches/default`, `build-status` historique) sont informatives : leur résultat n'entre pas dans l'état de la ligne. L'état d'une ligne est l'agrégat de ses sondes non optionnelles ; PARTIAL signale des sondes dans des états différents.

### Ce que l'on fait des résultats

1. `version_status` renseigne H-01 : CONFIRMED clôt l'hypothèse ; CONFLICTING impose de corriger la version déclarée avant toute validation du catalogue.
2. Chaque ligne AVAILABLE ou EMPTY devient `compatibility_checked: true` dans le catalogue ; ses `keys_observed` servent à valider les correspondances de champs (III.6).
3. Chaque ligne ERROR ou UNSUPPORTED est traitée avant le lot 1 si elle est P0 ; elle peut rester ouverte si elle est P1 ou P2.
4. Le dénominateur candidat fixe la valeur par défaut de D-06 et les ordres de grandeur de H-02 ; une mesure tronquée est relancée avec `--max-pages` plus élevé.
5. Les tranches d'activité et les dépôts archivés ou forks orientent la constitution de l'échantillon de contrôle (≥ 50 dépôts étiquetés à la main, V.5).
6. Le rapport HTML et le JSON sont archivés avec la date d'exécution : ils constituent la preuve de la découverte des capacités exigée par la séquence de démarrage.

## Dépannage

| Symptôme | Cause probable | Action |
|---|---|---|
| `Aucun secret fourni` | variable `BITBUCKET_TOKEN` absente | exporter la variable ou utiliser `--token-file` (fichier en mode 600) |
| Jeton refusé (HTTP 401), arrêt après l'étape 1 | jeton expiré, révoqué, mal copié ou compte différent | régénérer le jeton HTTP du compte de service ; vérifier qu'aucun espace ni retour à la ligne n'a été copié |
| HTTP 403 sur API-01 ou sur une famille | droits insuffisants du compte | revue des droits (D-02) ; en attendant, relancer en `--profile base` |
| HTTP 404 sur API-01 | URL de base incomplète (chemin de contexte) ou mauvais hôte | tester `https://hote/<contexte>/rest/api/latest/application-properties` dans un navigateur |
| HTTP 404 sur une sonde | route inexistante, ressource masquée ou échantillon inadapté | vérifier la route sur la documentation REST 9.4 ; changer de dépôt échantillon (`--sample-repo`) |
| HTTP 429 répétés | limitation de débit de l'instance | augmenter `--delay` (0,5 s) et `--max-retries` ; l'outil respecte `Retry-After` |
| `erreur TLS` | autorité interne inconnue de Python | `--ca-bundle /chemin/ca-entreprise.pem` ; ne pas utiliser `--insecure` hors test |
| `erreur de connexion` / `délai dépassé` | proxy, pare-feu ou hôte injoignable | `HTTPS_PROXY` correct ou `--no-proxy` ; `--timeout 60` ; tester l'URL depuis le poste d'exécution |
| Aucun projet retenu, arrêt après l'étape 2 | clés de projet inexactes | reprendre les clés listées dans la proposition (clés visibles) ; les clés sont sensibles à la casse côté Bitbucket mais comparées sans casse par l'outil |
| `Budget d'appels épuisé` | `--max-calls` trop bas pour le périmètre | relancer avec `--max-calls` plus élevé ou `--details sample` |
| Comptages suivis de « + » | liste tronquée par `--max-pages` | relancer avec `--max-pages 200` sur les projets concernés |
| Caractères accentués illisibles dans Excel | ouverture sans détection d'encodage | les CSV sont en UTF-8 avec BOM et séparateur « ; » : ouvrir par double-clic ou importer en UTF-8 |

*Dépannage*

`--verbose` ajoute un message par appel (chemin et statut HTTP, sans paramètre ni secret) et aide à localiser une sonde qui échoue. Le fichier `appels_<date>.csv` contient le même journal.

## Sécurité et conformité

- **Lecture seule** : le client construit exclusivement des requêtes GET et le vérifie à chaque appel ; toute autre méthode est structurellement impossible. L'outil peut être exécuté avec le compte à droits complets sans risque d'écriture ; le journal `appels_<date>.csv` en est la preuve.
- **Secrets** : jeton dans une variable d'environnement ou un fichier protégé, jamais sur la ligne de commande ; aucun secret dans les sorties, les journaux ni les messages d'erreur.
- **Données personnelles** : mode non nominatif systématique pour le pilote (D-05). Les contenus de fichiers et de diffs sont lus sur quelques kilo-octets pour établir l'état puis abandonnés ; `keys_observed` ne contient que des noms de champs. Les projets personnels sont comptés, jamais listés ni inventoriés.
- **Modération de charge** : délai entre appels, reprise bornée avec `Retry-After`, budget global d'appels, plafond de pages ; l'exécution standard représente moins de cent appels, l'inventaire une page par tranche de 100 dépôts.
- **Conservation** : sorties classifiées Interne, archivées avec le compte rendu du pilote ; purger les dossiers de sortie intermédiaires.

## Test hors ligne avec le simulateur

`mock_bitbucket_server.py` reproduit une instance 9.4.17 minimale : pagination, un dépôt vide, un dépôt archivé, un fork, des dates de dernier commit variées, des 404 sur `readme` et `license`, un 403 sur les permissions de groupe au niveau projet, un 429 avec `Retry-After` sur les affectations globales, un 401 sur jeton incorrect ; il refuse toute méthode autre que GET.

```bash
# terminal 1
python mock_bitbucket_server.py --port 8089 --token test-token

# terminal 2
export BITBUCKET_TOKEN=test-token
python bitbucket_discovery.py --base-url http://127.0.0.1:8089 --projects BPCEIT,BPCECIB --delay 0 --out ./out_test
```

Résultat attendu : 16 lignes AVAILABLE, 6 EMPTY, 1 PARTIAL (API-16, 403 sur les groupes), 1 ERROR (API-07, 404), 1 NOT_REQUESTED (API-25, pas de rapport Code Insights) ; 7 dépôts inventoriés dont 1 archivé et 1 fork ; 0 appel non GET. Le dossier `exemples/` du pack contient les sorties de ce test.

## Annexe — lignes du catalogue sondées

| ID | Prio. | Donnée recherchée | Sondes |
|---|---|---|---|
| API-01 | P0 | Version et build de l'instance | application-properties |
| API-02 | P0 | Projets accessibles | projects |
| API-03 | P0 | Repositories d'un projet | repos |
| API-04 | P0 | Identité, état et métadonnées du repository | repository |
| API-05 | P0 | Branche par défaut | default-branch ; branches/default (variante) |
| API-06 | P1 | Forks et relations | forks ; related |
| API-07 | P1 | README et licence détectée | readme ; license |
| API-08 | P0 | Branches et tags | branches ; tags |
| API-09 | P0 | Chemins, arborescence et contenu ciblé | files ; browse ; raw (un fichier, quelques Ko) |
| API-10 | P0 | Commits et identités Git | commits ; commit |
| API-11 | P1 | Changements et diffs d'un commit | changes ; diff (quelques Ko) |
| API-12 | P0 | PR et participants déclarés | pull-requests ; pull-request |
| API-13 | P1 | Actions et commentaires de PR | activities |
| API-14 | P1 † | Droits directs du repository | permissions/users ; permissions/groups |
| API-15 | P1 † | Recherche de droits directs/implicites | permissions/search |
| API-16 | P1 † | Affectations au niveau projet | project permissions/users ; project permissions/groups |
| API-17 | P1 † | Groupes et appartenance consultable | groups ; admin/groups/more-members |
| API-18 | P2 † | Affectations globales | admin/permissions/users ; admin/permissions/groups |
| API-19 | P1 † | Restrictions de branches | repo restrictions ; project restrictions |
| API-20 | P1 | Conditions de reviewers par défaut | default-reviewers conditions |
| API-21 | P1 † | Hooks et webhooks | repo et project settings/hooks ; repo et project webhooks |
| API-22 | P1 | Builds requis pour le merge | required-builds conditions |
| API-23 | P1 | Builds et déploiements liés au commit | commit builds ; commit deployments ; build-status (variante historique) |
| API-24 | P1 | Rapports Code Insights | insights reports |
| API-25 | P1 | Détail de rapport et annotations | insights report ; insights annotations |

*Catalogue API-01 à API-25 († = famille à droits étendus, exclue du profil BASE)*

Les familles P2 non listées (tokens, clés, secret scanning, audit, Jira, plugins) ne sont pas sondées : leurs endpoints restent à documenter avant activation (spécification III.6).
