#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
mock_bitbucket_server.py — simulateur minimal d'API Bitbucket Data Center pour tester bitbucket_discovery.py hors ligne.

Lancement :  python mock_bitbucket_server.py --port 8089 --token test-token
Puis :       BITBUCKET_TOKEN=test-token python bitbucket_discovery.py --base-url http://127.0.0.1:8089 --projects BPCEIT,BPCECIB --delay 0

Comportements simulés (volontairement variés pour exercer les états de collecte) :
  * pagination Data Center (start / limit / isLastPage / nextPageStart) ;
  * un dépôt vide (sans commit), un dépôt archivé, un fork, des dates de dernier commit variées ;
  * readme et license → 404 ; branches/default → 404 (variante) ; build-status → 404 ;
  * permissions de groupe au niveau projet → 403 ;
  * admin/permissions/users → 429 (Retry-After: 1) au premier appel puis 200 ;
  * jeton absent ou incorrect → 401.
Aucune méthode autre que GET n'est acceptée (405).
"""
import argparse
import json
import re
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs

PROJECTS = [
    {"key": "BPCEIT", "id": 1, "name": "BPCE IT", "type": "NORMAL", "public": False},
    {"key": "BPCECIB", "id": 2, "name": "BPCE CIB", "type": "NORMAL", "public": False},
    {"key": "OTHER", "id": 3, "name": "Autre périmètre", "type": "NORMAL", "public": False},
    {"key": "~JDOE", "id": 4, "name": "John Doe", "type": "PERSONAL", "public": False},
]
def _repo(slug, rid, archived=False, public=False, origin=None):
    r = {"slug": slug, "id": rid, "name": slug, "hierarchyId": "%012x" % rid, "scmId": "git", "state": "AVAILABLE",
         "statusMessage": "Available", "forkable": True, "archived": archived, "public": public}
    if origin:
        r["origin"] = {"slug": origin[1], "id": origin[2], "name": origin[1], "project": {"key": origin[0]}}
    return r


REPOS = {
    "BPCEIT": [_repo("payment-api", 11), _repo("empty-repo", 12), _repo("legacy-batch", 13, archived=True),
               _repo("payment-api-fork", 14, origin=("BPCEIT", "payment-api", 11))],
    "BPCECIB": [_repo("customer-ui", 21), _repo("infra-platform", 22), _repo("risk-engine", 23)],
    "OTHER": [_repo("misc", 31)],
    "~JDOE": [_repo("scratch", 41)],
}
# âge du dernier commit (jours) par dépôt, pour exercer les tranches d'activité
LAST_COMMIT_AGE_DAYS = {"payment-api": 12, "legacy-batch": 540, "payment-api-fork": 200, "customer-ui": 45, "infra-platform": 130, "risk-engine": 400, "misc": 30, "scratch": 700}
COMMIT = {"id": "a783cf4e9b2c1d0f5a6b7c8d9e0f1a2b3c4d5e6f", "displayId": "a783cf4", "author": {"name": "jane", "emailAddress": "jane@example.com"},
          "authorTimestamp": 1759600000000, "committer": {"name": "jane"}, "committerTimestamp": 1759600000000, "message": "feat: x"}


def commit_for(slug):
    """Commit échantillon dont la date dépend du dépôt (âge configuré dans LAST_COMMIT_AGE_DAYS)."""
    age = LAST_COMMIT_AGE_DAYS.get(slug, 370)
    ts = int((time.time() - age * 86400) * 1000)
    return dict(COMMIT, authorTimestamp=ts, committerTimestamp=ts)


PR = {"id": 42, "version": 3, "title": "Feature", "state": "MERGED", "open": False, "closed": True, "author": {"user": {"name": "jane"}, "role": "AUTHOR"},
      "reviewers": [], "participants": [], "createdDate": 1759500000000, "updatedDate": 1759600000000}
STATE = {"admin_users_calls": 0}


def page(values, start, limit):
    chunk = values[start:start + limit]
    last = start + limit >= len(values)
    body = {"size": len(chunk), "limit": limit, "isLastPage": last, "values": chunk, "start": start}
    if not last:
        body["nextPageStart"] = start + limit
    return body


class H(BaseHTTPRequestHandler):
    server_version = "MockBitbucket/9.4.17"
    token = "test-token"

    def log_message(self, fmt, *args):  # silencieux
        pass

    def _send(self, code, body=None, ctype="application/json;charset=UTF-8", headers=None):
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        for k, v in (headers or {}).items():
            self.send_header(k, v)
        data = b"" if body is None else (json.dumps(body).encode("utf-8") if not isinstance(body, (bytes, str)) else (body.encode("utf-8") if isinstance(body, str) else body))
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def do_POST(self): self._send(405, {"errors": [{"message": "GET only"}]})
    do_PUT = do_DELETE = do_PATCH = do_POST

    def do_GET(self):
        u = urlparse(self.path); q = parse_qs(u.query); p = u.path
        start = int(q.get("start", ["0"])[0]); limit = int(q.get("limit", ["25"])[0])
        auth = self.headers.get("Authorization", "")
        if auth != "Bearer " + self.token:
            return self._send(401, {"errors": [{"message": "Authentication failed"}]})
        A = "/rest/api/latest"
        if p == A + "/application-properties":
            return self._send(200, {"version": "9.4.17", "buildNumber": "900417", "buildDate": "1748000000000", "displayName": "Bitbucket"})
        if p == A + "/projects":
            return self._send(200, page(PROJECTS, start, min(limit, 2)))  # pages de 2 pour exercer la pagination
        m = re.match(r"^%s/projects/([^/]+)/repos$" % A, p)
        if m:
            key = m.group(1)
            if key not in REPOS: return self._send(404, {"errors": [{"message": "Project not found"}]})
            return self._send(200, page(REPOS[key], start, limit))
        m = re.match(r"^%s/projects/([^/]+)/permissions/(users|groups)$" % A, p)
        if m:
            if m.group(2) == "groups": return self._send(403, {"errors": [{"message": "insufficient permissions"}]})
            return self._send(200, page([{"user": {"name": "jane", "slug": "jane"}, "permission": "PROJECT_READ"}], start, limit))
        m = re.match(r"^%s/projects/([^/]+)/(settings/hooks|webhooks)$" % A, p)
        if m: return self._send(200, page([], start, limit))
        m = re.match(r"^%s/projects/([^/]+)/repos/([^/]+)(/.*)?$" % A, p)
        if m:
            key, slug, rest = m.group(1), m.group(2), m.group(3) or ""
            repo = next((r for r in REPOS.get(key, []) if r["slug"] == slug), None)
            if not repo: return self._send(404, {"errors": [{"message": "Repository not found"}]})
            empty = slug == "empty-repo"
            if rest == "": return self._send(200, dict(repo, project={"key": key}, scmId="git", state="AVAILABLE"))
            if rest == "/default-branch": return self._send(200, {"id": "refs/heads/main", "displayId": "main", "type": "BRANCH"})
            if rest in ("/forks", "/related"): return self._send(200, page([], start, limit))
            if rest in ("/readme", "/license", "/branches/default"): return self._send(404, {"errors": [{"message": "not found"}]})
            if rest == "/branches": return self._send(200, page([] if empty else [{"id": "refs/heads/main", "displayId": "main", "latestCommit": COMMIT["id"]}, {"id": "refs/heads/develop", "displayId": "develop"}], start, limit))
            if rest == "/tags": return self._send(200, page([] if empty else [{"id": "refs/tags/v1.0.0", "displayId": "v1.0.0"}], start, limit))
            if rest == "/files": return self._send(200, page([] if empty else ["pom.xml", "src/main/java/App.java", "Dockerfile"], start, limit))
            if rest == "/browse": return self._send(200, {"path": {"toString": ""}, "revision": "main", "children": page([{"path": {"toString": "pom.xml"}, "type": "FILE"}], 0, limit)})
            if rest.startswith("/raw/"): return self._send(200, "<project>…</project>\n", ctype="text/plain")
            if rest == "/commits": return self._send(200, page([] if empty else [commit_for(slug)] * 3, start, limit))
            if rest == "/commits/" + COMMIT["id"]: return self._send(200, commit_for(slug))
            if rest == "/commits/%s/changes" % COMMIT["id"]: return self._send(200, page([{"path": {"toString": "pom.xml"}, "type": "MODIFY"}], start, limit))
            if rest == "/commits/%s/diff" % COMMIT["id"]: return self._send(200, "diff --git a/pom.xml b/pom.xml\n", ctype="text/plain")
            if rest in ("/commits/%s/builds" % COMMIT["id"], "/commits/%s/deployments" % COMMIT["id"]): return self._send(200, page([], start, limit))
            if rest == "/pull-requests": return self._send(200, page([] if empty else [PR], start, limit))
            if rest == "/pull-requests/42": return self._send(200, PR)
            if rest == "/pull-requests/42/activities": return self._send(200, page([{"id": 1, "action": "OPENED", "user": {"name": "jane"}}], start, limit))
            if rest in ("/permissions/users", "/permissions/groups", "/permissions/search"): return self._send(200, page([{"user": {"name": "jane"}, "permission": "REPO_WRITE"}], start, limit))
            if rest in ("/settings/hooks", "/webhooks"): return self._send(200, page([], start, limit))
            return self._send(404, {"errors": [{"message": "no route"}]})
        if p == A + "/groups": return self._send(200, page(["bitbucket-users", "appsec"], start, limit))
        if p == A + "/admin/groups/more-members": return self._send(200, page([{"name": "jane"}], start, limit))
        if p == A + "/admin/permissions/users":
            STATE["admin_users_calls"] += 1
            if STATE["admin_users_calls"] == 1: return self._send(429, {"errors": [{"message": "rate limited"}]}, headers={"Retry-After": "1"})
            return self._send(200, page([{"user": {"name": "admin"}, "permission": "ADMIN"}], start, limit))
        if p == A + "/admin/permissions/groups": return self._send(200, page([], start, limit))
        if p.startswith("/rest/branch-permissions/latest/"): return self._send(200, page([{"id": 1, "type": "read-only", "matcher": {"id": "refs/heads/main"}}], start, limit))
        if p.startswith("/rest/default-reviewers/latest/"): return self._send(200, [])
        if p.startswith("/rest/required-builds/latest/"): return self._send(200, page([], start, limit))
        if p.startswith("/rest/build-status/latest/"): return self._send(404, {"errors": [{"message": "legacy route disabled"}]})
        if p.startswith("/rest/insights/latest/"): return self._send(200, page([], start, limit))
        return self._send(404, {"errors": [{"message": "no route"}]})


def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--port", type=int, default=8089); ap.add_argument("--token", default="test-token")
    a = ap.parse_args(); H.token = a.token
    srv = ThreadingHTTPServer(("127.0.0.1", a.port), H)
    print("mock Bitbucket Data Center 9.4.17 on http://127.0.0.1:%d (token: %s)" % (a.port, a.token))
    srv.serve_forever()


if __name__ == "__main__":
    main()
